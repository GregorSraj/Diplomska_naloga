# standard-test-images-for-Image-Processing
Collection of standard test images for image processing
